package com.example.test_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recycler_view_account)
        recyclerView.layoutManager = LinearLayoutManager(this)


        val client = createSupabaseClient(
            supabaseUrl = "https://mvcrishankajzjqoaqak.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im12Y3Jpc2hhbmthanpqcW9hcWFrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwMzUxMDgsImV4cCI6MjAxNTYxMTEwOH0.x0i-mcjZudNssMFOKQ5XivX6D_6LcfN4D1u9IaWIO74"
        ) {
            install(Postgrest)
        }
        lifecycleScope.launch {
           val username = client.from("account").select().decodeSingle<account>()
            Log.e("!", "id: " + username.id + "| un: " + username.username)
        }

    }
    @Serializable
    data class account(var id: String = "", var username: String ="")
}