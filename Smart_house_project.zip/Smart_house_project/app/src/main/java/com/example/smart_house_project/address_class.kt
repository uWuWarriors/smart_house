package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.gotrue.gotrue
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Returning
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializer
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class address_class : AppCompatActivity() {
    var adress_p: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.address_activity)
        var name = intent.getStringExtra("name")
        val btnSave = findViewById(R.id.btn_save_address) as Button
        val client = createSupabaseClient(
            supabaseUrl = "https://frwzdxnvfejlwekzzhat.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyd3pkeG52ZmVqbHdla3p6aGF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTgzMTIzMTIsImV4cCI6MjAxMzg4ODMxMn0.Hcftjvx9ruC4rxSZhzjB79iU9sWVOfmkMhp87W4vBiA"
        ) {
            install(GoTrue)
            install(Postgrest)
        }

        val AddressPattern =
            Regex("city. " + "[a-zA-Z0-9\\\\+\\\\.\\\\_\\\\%\\\\-\\\\+]{1,256}" + ", " + "street. " + "[a-zA-Z0-9][a-zA-Z0-9\\\\-]{0,64}" + ", " + "[1-100]")
        val edit_address = findViewById(R.id.address_edit) as EditText
        edit_address.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                p0: CharSequence?,
                p1: Int, p2: Int, p3: Int
            ) {
            }

            override fun onTextChanged(
                p0: CharSequence?,
                p1: Int, p2: Int, p3: Int
            ) {
                if (p0 != null) {
                    if (p0.matches(AddressPattern)) {
                        edit_address.error = null
                    } else {
                        edit_address.error = "Неправильный адрес."
                    }
                }
            }

            override fun afterTextChanged(p0: Editable?) {
                adress_p = edit_address.text.toString()
            }
        })
        btnSave.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, Profile_class::class.java)
                startActivity(intent)
                lifecycleScope.launch {
                    val user = client.gotrue.retrieveUserForCurrentSession(updateSession = true)
                    //var profile1 = profile(user.id.toString(), username = name.toString(), adress = adress_p.toString())
                    client.postgrest["profile"].update({
                        set("adress",adress_p.toString() )
                    })
                    {
                        eq("id", user.id.toString())
                    }//, returning = Returning.MINIMAL) //returning defaults to Returning.REPRESENTATION

                }
            }
        })
    }
}
@kotlinx.serialization.Serializable
data class profile(var id: String = "", var username: String ="", var adress: String = "")
/*@kotlinx.serialization.Serializable
data class profileAdress(var adress: String = "")*/
