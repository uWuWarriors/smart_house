package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText

class address_class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.address_activity)
        val btnSave = findViewById(R.id.btn_save_address) as Button
        btnSave.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, room_available_Class::class.java)
                startActivity(intent)
            }
        })
       val AddressPattern = Regex( "city." + "[a-zA-Z]" + "," + "street." +"[a-zA-z]" + "," + "[1-100]")//+ "," + "a-zA-z" + "," + "1-100")
        val edit_address = findViewById(R.id.address_edit) as EditText
        edit_address.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.matches(AddressPattern)){
                        edit_address.error = null
                    }else{
                        edit_address.error = "Неправильный адрес."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
            }
        })
    }
}