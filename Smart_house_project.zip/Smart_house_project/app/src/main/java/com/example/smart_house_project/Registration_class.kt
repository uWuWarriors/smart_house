package com.example.smart_house_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Registration_class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registration_activity)
    }
}