package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText

class Registration_class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registration_activity)
        val name_edit = findViewById(R.id.name_edit) as EditText
        val email_edit = findViewById(R.id.email_edit) as EditText
        val password_edit = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log) as Button
        val btnReg = findViewById(R.id.button_registration) as Button
        btnReg.isEnabled = false
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, Login_class::class.java)
                startActivity(intent)
            }
        })
        email_edit.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    email_edit.error = null
                    btnReg.isEnabled = true
                }else{
                    email_edit.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
            }
        })
        name_edit.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        name_edit.error = null
                        btnReg.isEnabled = true
                    }else{
                        name_edit.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {

            }
        })
        password_edit.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        btnReg.isEnabled = true
                        password_edit.error = null
                    }else{
                        password_edit.error = "Нужно ввести имя пользователя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {

            }
        })

    }
}