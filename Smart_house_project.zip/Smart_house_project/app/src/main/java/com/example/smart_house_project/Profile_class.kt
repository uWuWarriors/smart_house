package com.example.smart_house_project

import android.R.array
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.gotrue.gotrue
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.result.PostgrestResult
import kotlinx.coroutines.launch
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import org.json.JSONArray
import org.json.JSONObject


class Profile_class : AppCompatActivity() {
    var mail: String? = null
    var name: String? = null
    var adress_edit: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile_user_activity)
        val btn_save = findViewById(R.id.btn_save_profile) as Button
        val btn_exit = findViewById(R.id.btn_exit_profile) as Button
        val edit_email = findViewById(R.id.email_edit) as EditText
        val address_edit = findViewById(R.id.address_edit) as EditText
        var edit_name = findViewById(R.id.name_edit) as EditText
        var bundle :Bundle ?=intent.extras
        var id = bundle?.getString("ID")
        var email = bundle?.getString("EMAIL")
        val client = createSupabaseClient(
            supabaseUrl = "https://frwzdxnvfejlwekzzhat.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyd3pkeG52ZmVqbHdla3p6aGF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTgzMTIzMTIsImV4cCI6MjAxMzg4ODMxMn0.Hcftjvx9ruC4rxSZhzjB79iU9sWVOfmkMhp87W4vBiA"
        ) {
            install(GoTrue)
            install(Postgrest)
        }
        lifecycleScope.launch {
            var username = client.postgrest["profile"].select(){
                eq("id" , id!!)
            }

            val buf = StringBuilder()
            buf.append(username.body.toString()).append("\n");
            val itemObj: JSONObject = JSONArray(buf.toString()).getJSONObject(0) //TODO Разбитие массива в объект
            name = itemObj.getString("username")
            val adress = itemObj.getString("adress")
            address_edit.setText(adress.toString())
            edit_name.setText(name.toString())
            edit_email.setText(email)
        }

        edit_email.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_email.error = null
                }else{
                    edit_email.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail= edit_email.text.toString()
            }
        })
        address_edit.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        address_edit.error = null
                    }else{
                        address_edit.error = "Нужно ввести адрес."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                adress_edit= address_edit.text.toString()
            }
        })
        edit_name.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        edit_name.error = null
                    }else{
                        edit_name.error = "Нужно ввести имя."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                name = edit_name.text.toString()
            }
        })
        btn_save.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {

                    val user = client.gotrue.retrieveUserForCurrentSession()
                    Log.e("!", user.id)
                    client.postgrest["profile"].update({
                        set("adress",adress_edit.toString() )
                    })
                    {
                        eq("id", user.id.toString())
                    }
                    client.postgrest["profile"].update({
                        set("username",name.toString() )
                    })
                    {
                        eq("id", user.id.toString())
                    }
                    client.postgrest["auth.users.id"].update({
                        set("email",mail.toString() )
                    })
                    {
                        eq("id", user.id.toString())
                    }
                    intent.putExtra("ID", user.id)
                    intent.putExtra("EMAIL", user.email.toString())
                    startActivity(intent)

                }
                val intent = Intent(applicationContext, Login_class::class.java)
                startActivity(intent)
            }
        })
    }
}
@kotlinx.serialization.Serializable
data class profile1(var email: String = "")