package com.example.smart_house_project

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class PIN_reg_class : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pincode_activity_reg)

        val img1 = findViewById(R.id.img_pin1) as ImageView
        val img2 = findViewById(R.id.img_pin2) as ImageView
        val img3 = findViewById(R.id.img_pin3) as ImageView
        val img4 = findViewById(R.id.img_pin4) as ImageView
        val btn1 = findViewById(R.id.btn1) as Button
        val btn2 = findViewById(R.id.btn2) as Button
        val btn3 = findViewById(R.id.btn3) as Button
        val btn4 = findViewById(R.id.btn4) as Button
        val btn5 = findViewById(R.id.btn5) as Button
        val btn6 = findViewById(R.id.btn6) as Button
        val btn7 = findViewById(R.id.btn7) as Button
        val btn8 = findViewById(R.id.btn8) as Button
        val btn9 = findViewById(R.id.btn9) as Button
        img1.setImageResource(R.drawable.ellipse_no)
        img2.setImageResource(R.drawable.ellipse_no)
        img3.setImageResource(R.drawable.ellipse_no)
        img4.setImageResource(R.drawable.ellipse_no)
    }
    fun onClick(v: View) {
        var value = ""
        var i = 1
        when (v.id) {
            R.id.btn1 -> value = value + "1"
            R.id.btn2 -> value = value + "2"
            R.id.btn3 -> value = value + "3"
            R.id.btn4 -> value = value + "4"
            R.id.btn5 -> value = value + "5"
            R.id.btn6 -> value = value + "6"
            R.id.btn7 -> value = value + "7"
            R.id.btn8 -> value = value + "8"
            R.id.btn9 -> value = value + "9"
        }
        i++
        when (i) {
            1, 2, 3, 4 -> {}
        }
        if (i == 1) {
            img1.setImageResource(R.drawable.elipse_yes)
        }
        if (i == 2) {
            img2.setImageResource(R.drawable.elipse_yes)
        }
        if (i == 3) {
            img3.setImageResource(R.drawable.elipse_yes)
        }
        if (i == 4) {
            img4.setImageResource(R.drawable.elipse_yes)
            val intent = Intent(this@PIN_reg_class, room_available_Class::class.java)
            startActivity(intent)
        }
    }
}