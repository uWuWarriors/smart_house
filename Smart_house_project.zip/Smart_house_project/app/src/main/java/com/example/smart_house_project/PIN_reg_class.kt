package com.example.smart_house_project

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class PIN_reg_class : AppCompatActivity() {

    var img1: ImageView? = null
    var img2: ImageView? = null
    var img3: ImageView? = null
    var img4: ImageView? = null
    var i = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pincode_activity_reg)
        img1 = findViewById(R.id.img_pin1) as ImageView
        img2 = findViewById(R.id.img_pin2) as ImageView
        img2 = findViewById(R.id.img_pin2) as ImageView
        img3 = findViewById(R.id.img_pin3) as ImageView
        img4 = findViewById(R.id.img_pin4) as ImageView
        img1!!.setImageResource(R.drawable.ellipse_no)
        img2!!.setImageResource(R.drawable.ellipse_no)
        img3!!.setImageResource(R.drawable.ellipse_no)
        img4!!.setImageResource(R.drawable.ellipse_no)
    }
    fun onClick(v: View) {
        Log.e("!", "1");
        var value = ""
        when (v.id) {
            R.id.btn1 -> value = value + "1"
            R.id.btn2 -> value = value + "2"
            R.id.btn3 -> value = value + "3"
            R.id.btn4 -> value = value + "4"
            R.id.btn5 -> value = value + "5"
            R.id.btn6 -> value = value + "6"
            R.id.btn7 -> value = value + "7"
            R.id.btn8 -> value = value + "8"
            R.id.btn9 -> value = value + "9"
        }
        i++
        if (i == 2) {
            img1!!.setImageResource(R.drawable.elipse_yes)

        }
        if (i == 3) {
            img2!!.setImageResource(R.drawable.elipse_yes)


        }
        if (i == 4) {
            img3!!.setImageResource(R.drawable.elipse_yes)

        }
        if (i == 5) {
            img4!!.setImageResource(R.drawable.elipse_yes)

            val intent = Intent(this, address_class::class.java)
            startActivity(intent)
        }
    }
}